package AST;

public abstract class ComparsionAbstractClass implements ASTNode {

	@Override
	public void print() {
		// TODO Auto-generated method stub

	}

}
