package AST;

public abstract class ElifExpressionAbstract implements ASTNode {

	@Override
	public void print() {
		// TODO Auto-generated method stub

	}

}
