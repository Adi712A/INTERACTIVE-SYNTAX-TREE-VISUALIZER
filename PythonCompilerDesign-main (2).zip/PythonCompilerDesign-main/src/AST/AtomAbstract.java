package AST;

public abstract class AtomAbstract implements ASTNode {

	@Override
	public void print() {
		// TODO Auto-generated method stub

	}

}
