package AST;

public abstract class ArgumentsClasses implements ASTNode {

	@Override
	public void print() {
		// TODO Auto-generated method stub

	}

}
