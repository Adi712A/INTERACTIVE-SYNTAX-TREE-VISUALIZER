package AST;

public abstract class DecoratorAbstractClass implements ASTNode {

	@Override
	public void print() {
		// TODO Auto-generated method stub

	}

}
