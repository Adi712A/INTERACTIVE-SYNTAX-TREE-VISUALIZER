package AST;

public interface ASTNode {
	void print();

}
