package AST;

public class NullStmt implements ASTNode {
	
	public NullStmt() {
		
	}

	@Override
	public void print() {
		// TODO Auto-generated method stub
		System.out.println(" ");

	}

}
