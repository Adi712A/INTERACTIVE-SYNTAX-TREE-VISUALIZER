Step1: Download and unzip the file<br><br>
Step2: Import the project in eclipse<br><br>
Step3: Windows-->preferences-->ANTLR4-->tool<br><br>
![image](https://github.com/DasariHarsha/PythonCompilerDesign/assets/85623307/04a2c99c-6b68-4cb7-8e3a-3371567ffada)<br><br>
Step4:Right click on the project name (CompilerDesignLexer) ---> java build path<br><br>
Step5:Add the class path i.e(ANTLR 4.10.1) from the external jars<br><br>
![image](https://github.com/DasariHarsha/PythonCompilerDesign/assets/85623307/0f222ffe-bcbe-42cb-9376-8e647fa0037c)<br><br>
Step6:Go to Run debug settings<br><br>
Step7:Select new --> java application --> Arguments<br><br>
Step8:Change the program arguments as input<br><br>
Step9:change the working directory as other "${workspace_loc:CompilerdesignLexer/src}"<br><br>
![image](https://github.com/DasariHarsha/PythonCompilerDesign/assets/85623307/090bc632-f031-463a-8150-35b54f7c09cb)<br><br>


